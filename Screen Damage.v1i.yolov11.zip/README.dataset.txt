# Screen Damage > 2026-02-06 10:34pm
https://universe.roboflow.com/qhacks/screen-damage-buzm4-qhvl8

Provided by a Roboflow user
License: CC BY 4.0

