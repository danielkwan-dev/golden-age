# Phone Damage > 2026-02-06 10:31pm
https://universe.roboflow.com/qhacks/phone-damage-24air

Provided by a Roboflow user
License: CC BY 4.0

